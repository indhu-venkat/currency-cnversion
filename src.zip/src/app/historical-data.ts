export interface HistoricalData {
    date: string;
    rate: number;
  }
  