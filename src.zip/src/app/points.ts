export interface Points {
  High: number;
  Low: number;
  Average: number;
}
